 # AgroManager
*Sistema de Gerenciamento de Fazendas.*

---

<p align="center">
<img width="400" height="400" alt="Image" src="https://github.com/user-attachments/assets/59c86ebd-564e-49be-9a14-f240ed141c95" />
</p>




---

## 👨‍💻 Equipe de Desenvolvimento

| Nome | GitHub |
|------|---------|
| Tayane Silva | [@SilvaTayane ](https://github.com/silvatayane) |
| João Gabriel | [@JoaoGAlmeidaS](https://github.com/JoaoGAlmeidaS) |
| Daniel Bonfim | [@danielbarros19](https://github.com/danielbarros19) |
| Danilo Vinicius | [@danilovinicius51](https://github.com/danilovinicius51) |
| Gustavo Curado| [@Guxtavoc](https://github.com/Guxtavoc) |
| Marcus Vinicius| [@gitvinidev](https://github.com/gitvinidev) |

---

## 🎯 Visão de Produto
*O AgroManager busca oferecer uma plataforma simples, eficiente e acessível para o gerenciamento de atividades no campo. Para auxiliar os gestores e trabalhadores no planejamento, acompanhamento e execução de tarefas agrícolas e pecuárias, facilitando a organização do dia a dia e promovendo uma gestão mais produtiva.*

---

## ⚙️ Funcionalidades
- Cadastro de Atividades
- Controle de Estoque 
- Localização de Animais e equipamentos  
- Monitoramento climático
- Relatórios

---

## 🧑‍🤝‍🧑 Atores
- **Administrador**: Cadastrar atividades, controle de estoque e localização dos animais e equipamentos, visualização das atividades realizadas na fazenda e emitir relatórios.
- **Funcionário**: Checklist das atividades e visualização de avisos climáticos.  
